# import pandas as pd
# data = {'a':[1,2,3,4],
#         'b':list('abcd')}

# print(pd.DataFrame(data))
# # Sir me django me mysql workbench se ek table featch ka ke dataframe bna rha hu 
# or mere table me 150000+ rows h to ye to bhot slow ka dega 
# agae mujhe same kan sabhi graph ke kiye kruga to web site slow ho jayegi 
# yo sabhi chart ek hi function me bnane chahiye

# def index(request):
#     obj = Ipl.objects.all()

#     data = []
#     for i in obj:
#         data.append({
#             'match_id': i.match_id,
#             'inning': i.inning,
#             'batting_team': i.batting_team,
#             'bowling_team': i.bowling_team,
#             'over': i.over,
#             'ball': i.ball,
#             'batsman': i.batsman,
#             'non_striker': i.non_striker,
#             'bowler': i.bowler,
#             'is_super_over': i.is_super_over,
#             'wide_runs': i.wide_runs,
#             'bye_runs': i.bye_runs,
#             'legbye_runs': i.legbye_runs,
#             'noball_runs': i.noball_runs,
#             'penalty_runs': i.penalty_runs,
#             'batsman_runs': i.batsman_runs,
#             'extra_runs': i.extra_runs,
#             'total_runs': i.total_runs,
#             'player_dismissed': i.player_dismissed,
#             'dismissal_kind': i.dismissal_kind,
#             'fielder': i.fielder,
#     })

#     df = pd.DataFrame(data)

#     print(df)

#     return render(request,'index.html')
batsman_10 = 'Ritu'
batsman_10 = '''<div  class="col-8">
                     {% if '''+ batsman_10 +''' %} 
                     {{ '''+batsman_10+'''|safe }} 
                    {% else %} 
                    <h3>No graph was provided.</h3>
                        {% endif %}
                          </div>'''
print(batsman_10)



'''Good evening Sir,

Today I Nevbar and create 5 Button on in 

Last Match
Last Match 10
Last Match 100
Last Match 500
Clear Filter

based on thise button over cheart get updated without page refresh
'''