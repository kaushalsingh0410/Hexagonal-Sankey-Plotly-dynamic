from django.db import models

# Create your models here.


class Ipl(models.Model):
    match_id = models.AutoField(primary_key=True)
    inning  = models.SmallIntegerField( null=True, default=None)
    batting_team = models.CharField(max_length=100, null=True, default=None)
    bowling_team = models.CharField(max_length=100, null=True, default=None)
    over = models.SmallIntegerField( null=True, default=None)
    ball = models.SmallIntegerField( null=True, default=None)
    batsman = models.CharField(max_length=100, null=True, default=None)
    non_striker = models.CharField(max_length=100, null=True, default=None)
    bowler = models.CharField(max_length=100, null=True, default=None)
    is_super_over = models.SmallIntegerField( null=True, default=None)
    wide_runs = models.SmallIntegerField( null=True, default=None)
    bye_runs = models.SmallIntegerField( null=True, default=None)
    legbye_runs = models.SmallIntegerField( null=True, default=None)
    noball_runs = models.SmallIntegerField( null=True, default=None)
    penalty_runs = models.SmallIntegerField( null=True, default=None)
    batsman_runs = models.SmallIntegerField( null=True, default=None)
    extra_runs = models.SmallIntegerField( null=True, default=None)
    total_runs = models.SmallIntegerField( null=True, default=None)
    player_dismissed = models.CharField(max_length=100, null=True, default=None)
    dismissal_kind = models.CharField(max_length=100, null=True, default=None)
    fielder = models.CharField(max_length=100, null=True, default=None)

    class Meta:
        db_table = 'ipl'
        managed = False